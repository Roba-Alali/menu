import Link from "next/link";
import { ArrowUpRight, Building2, ChartNoAxesCombined, ClipboardList, QrCode, ShieldCheck, Store } from "lucide-react";

const modules = [
  { icon: Store, title: "Restaurant websites", text: "Branded, mobile-first digital menus for every restaurant." },
  { icon: ClipboardList, title: "Menu & catalog", text: "Categories, products, modifiers, availability and pricing." },
  { icon: QrCode, title: "QR experiences", text: "QR entry points for menus, branches and tables." },
  { icon: ChartNoAxesCombined, title: "Orders & analytics", text: "Order operations, performance metrics and reports." },
  { icon: Building2, title: "Multi-tenant control", text: "Separate workspaces, domains, staff and restaurant data." },
  { icon: ShieldCheck, title: "Access control", text: "Role-based permissions and tenant-level data isolation." }
];

export default function Home() {
  return <main className="min-h-screen">
    <header className="border-b border-[#252d2b]">
      <div className="container flex h-20 items-center justify-between">
        <Link href="/" className="text-xl font-semibold tracking-[.22em]">MENU<span className="gold">.</span></Link>
        <nav className="hidden gap-8 text-sm text-[#aab4af] md:flex"><a href="#platform">Platform</a><a href="#modules">Modules</a><a href="#architecture">Architecture</a></nav>
        <Link href="/admin" className="rounded-full border border-[#c8a66a] px-5 py-2.5 text-sm text-[#e5c991]">Platform dashboard <ArrowUpRight className="ml-2 inline" size={15}/></Link>
      </div>
    </header>
    <section id="platform" className="container grid min-h-[620px] items-center gap-12 py-20 md:grid-cols-[1.1fr_.9fr]">
      <div>
        <div className="mb-6 inline-flex rounded-full border border-[#55472f] bg-[#1a1711] px-4 py-2 text-xs tracking-[.16em] text-[#d6b77d]">WHITE-LABEL RESTAURANT PLATFORM</div>
        <h1 className="max-w-3xl text-5xl font-semibold leading-[1.08] tracking-tight md:text-7xl">One platform.<br/><span className="gold">Every restaurant.</span></h1>
        <p className="muted mt-7 max-w-xl text-lg leading-8">Create elegant digital menu experiences, give every restaurant its own workspace, and manage your entire client portfolio from one place.</p>
        <div className="mt-9 flex flex-wrap gap-3"><Link className="rounded-full bg-[#c8a66a] px-7 py-3.5 font-medium text-[#10110e]" href="/admin">Explore dashboard</Link><a className="rounded-full border border-[#39413e] px-7 py-3.5" href="/demo">View menu demo</a><a className="rounded-full border border-[#39413e] px-7 py-3.5" href="/dashboard">Restaurant workspace</a></div>
        <div className="mt-14 flex gap-10 text-sm"><div><b className="text-2xl">01</b><p className="muted mt-1">Central platform</p></div><div><b className="text-2xl">∞</b><p className="muted mt-1">Restaurant tenants</p></div><div><b className="text-2xl">24/7</b><p className="muted mt-1">Digital presence</p></div></div>
      </div>
      <div className="panel relative overflow-hidden p-5">
        <div className="mb-5 flex items-center justify-between"><span className="text-sm tracking-widest">RESTAURANT PREVIEW</span><span className="rounded-full bg-[#1e3029] px-3 py-1 text-xs text-[#9ed2b5]">LIVE CONCEPT</span></div>
        <div className="rounded-2xl bg-[#171d1b] p-5">
          <div className="flex items-center justify-between"><div><p className="text-xs tracking-[.2em] text-[#c8a66a]">THE HOUSE</p><h2 className="mt-2 text-3xl">Food, thoughtfully.</h2></div><div className="h-12 w-12 rounded-full border border-[#76613f]"/></div>
          <div className="mt-7 flex gap-2 overflow-hidden text-xs"><span className="rounded-full bg-[#c8a66a] px-4 py-2 text-black">All</span><span className="rounded-full bg-[#29312e] px-4 py-2">Starters</span><span className="rounded-full bg-[#29312e] px-4 py-2">Mains</span><span className="rounded-full bg-[#29312e] px-4 py-2">Desserts</span></div>
          <div className="mt-5 grid grid-cols-2 gap-3">
            <div className="rounded-xl bg-[#222a27] p-3"><div className="mb-3 aspect-[1.4] rounded-lg bg-gradient-to-br from-[#82664b] to-[#30271f]"/><b>Truffle pasta</b><p className="muted mt-1 text-xs">Creamy parmesan · 18</p></div>
            <div className="rounded-xl bg-[#222a27] p-3"><div className="mb-3 aspect-[1.4] rounded-lg bg-gradient-to-br from-[#a17a4f] to-[#443323]"/><b>Grilled salmon</b><p className="muted mt-1 text-xs">Herb butter · 24</p></div>
          </div>
        </div>
        <div className="absolute -right-12 -top-12 h-40 w-40 rounded-full bg-[#c8a66a]/10 blur-3xl"/>
      </div>
    </section>
    <section id="modules" className="border-y border-[#252d2b] bg-[#0d1010] py-20"><div className="container"><p className="gold text-xs tracking-[.22em]">PLATFORM MODULES</p><h2 className="mt-4 text-3xl font-semibold md:text-4xl">Everything your clients need.</h2><div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{modules.map(({icon:Icon,title,text})=><div className="panel p-6" key={title}><Icon className="gold" size={25}/><h3 className="mt-5 text-lg font-medium">{title}</h3><p className="muted mt-2 text-sm leading-6">{text}</p></div>)}</div></div></section>
    <section id="architecture" className="container py-20"><p className="gold text-xs tracking-[.22em]">BUILT TO SCALE</p><h2 className="mt-4 text-3xl font-semibold">One core. Isolated client spaces.</h2><p className="muted mt-4 max-w-2xl leading-7">Each restaurant receives its own menu, brand settings, branches, staff roles and domain configuration. Platform administrators manage tenants centrally while database policies protect tenant data.</p><div className="mt-8 flex flex-wrap gap-3 text-xs">{["Next.js","Supabase","PostgreSQL RLS","Cloudflare R2","Custom domains","QR ordering"].map(x=><span className="rounded-full border border-[#39413e] px-4 py-2" key={x}>{x}</span>)}</div></section>
    <footer className="border-t border-[#252d2b] py-8"><div className="container flex justify-between text-xs text-[#8e9994]"><span>MENU PLATFORM · FOUNDATION BUILD</span><span>White-label restaurant SaaS</span></div></footer>
  </main>;
}
