"use client";

import { useMemo, useState } from "react";
import {
  LayoutDashboard, Palette, Utensils, FolderOpen, Image as ImageIcon,
  Globe2, QrCode, Settings, Plus, Search, MoreHorizontal, Eye,
  Package, TrendingUp, Store, ChevronDown, Check, X, Pencil, Trash2
} from "lucide-react";

type Product = { id: number; name: string; category: string; price: number; status: "Available" | "Sold out"; featured: boolean };
const initialProducts: Product[] = [
  { id: 1, name: "Truffle tagliatelle", category: "Main courses", price: 68, status: "Available", featured: true },
  { id: 2, name: "Charcoal grilled salmon", category: "Main courses", price: 92, status: "Available", featured: false },
  { id: 3, name: "Burrata & heirloom tomato", category: "Starters", price: 54, status: "Available", featured: true },
  { id: 4, name: "Pistachio cloud", category: "Desserts", price: 42, status: "Sold out", featured: false }
];

const nav = [
  { label: "Overview", icon: LayoutDashboard },
  { label: "Menu & products", icon: Utensils },
  { label: "Categories", icon: FolderOpen },
  { label: "Brand identity", icon: Palette },
  { label: "Media library", icon: ImageIcon },
  { label: "Branches", icon: Store },
  { label: "QR codes", icon: QrCode },
  { label: "Website & domain", icon: Globe2 },
  { label: "Settings", icon: Settings }
];

export default function RestaurantDashboard() {
  const [active, setActive] = useState("Menu & products");
  const [products, setProducts] = useState(initialProducts);
  const [query, setQuery] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Main courses");
  const [price, setPrice] = useState("0");
  const [status, setStatus] = useState<"Available" | "Sold out">("Available");
  const [brandColor, setBrandColor] = useState("#c8a66a");
  const [restaurantName, setRestaurantName] = useState("The House");
  const filtered = useMemo(() => products.filter(p => `${p.name} ${p.category}`.toLowerCase().includes(query.toLowerCase())), [products, query]);

  function openNew() {
    setEditing(null); setName(""); setCategory("Main courses"); setPrice("0"); setStatus("Available"); setShowForm(true);
  }
  function openEdit(p: Product) {
    setEditing(p); setName(p.name); setCategory(p.category); setPrice(String(p.price)); setStatus(p.status); setShowForm(true);
  }
  function saveProduct(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    if (editing) setProducts(items => items.map(p => p.id === editing.id ? { ...p, name, category, price: Number(price), status } : p));
    else setProducts(items => [{ id: Math.max(0, ...items.map(p => p.id)) + 1, name, category, price: Number(price), status, featured: false }, ...items]);
    setShowForm(false);
  }
  function removeProduct(id: number) {
    if (window.confirm("Delete this product from the demo workspace?")) setProducts(items => items.filter(p => p.id !== id));
  }

  return <main className="min-h-screen bg-[#090b0b] text-[#f5f5f1]">
    <aside className="fixed inset-y-0 left-0 hidden w-[250px] border-r border-[#252d2b] bg-[#0d1010] px-5 py-6 lg:block">
      <a href="/" className="text-2xl font-semibold tracking-[.2em]">MENU<span className="gold">.</span></a>
      <p className="muted mt-1 text-[10px] tracking-[.18em]">RESTAURANT WORKSPACE</p>
      <div className="mt-9 flex items-center gap-3 rounded-xl border border-[#29312e] bg-[#151b18] p-3">
        <div className="grid h-10 w-10 place-items-center rounded-full border border-[#c8a66a] text-sm gold">TH</div>
        <div className="min-w-0"><p className="truncate text-sm font-medium">{restaurantName}</p><p className="muted text-[10px]">Growth workspace</p></div>
        <ChevronDown size={14} className="muted"/>
      </div>
      <nav className="mt-8 space-y-1">{nav.map(({label,icon:Icon})=><button onClick={()=>setActive(label)} key={label} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] transition ${active===label?"bg-[#252d29] text-white":"text-[#9da8a2] hover:bg-[#171e1b] hover:text-white"}`}><Icon size={17}/>{label}</button>)}</nav>
      <div className="panel absolute bottom-5 left-5 right-5 p-4"><p className="text-xs font-medium">Need a hand?</p><p className="muted mt-1 text-[11px] leading-5">Contact your platform administrator for help with your workspace.</p><button className="mt-3 text-xs gold">Contact support ↗</button></div>
    </aside>

    <section className="lg:ml-[250px]">
      <header className="flex h-[76px] items-center justify-between border-b border-[#252d2b] px-5 md:px-9">
        <div><p className="text-sm font-medium">{active}</p><p className="muted mt-1 text-[10px]">Manage your restaurant presence</p></div>
        <div className="flex items-center gap-3"><a href="/demo" className="hidden rounded-full border border-[#39413e] px-4 py-2 text-xs sm:block"><Eye className="mr-2 inline" size={14}/>View live menu</a><div className="grid h-9 w-9 place-items-center rounded-full bg-[#29312e] text-xs">TH</div></div>
      </header>

      <div className="p-5 md:p-9">
        {active === "Menu & products" ? <>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div><p className="gold text-[10px] tracking-[.2em]">CATALOG MANAGEMENT</p><h1 className="mt-2 text-3xl font-semibold">Menu & products</h1><p className="muted mt-2 text-sm">Create, organize and update the items on your digital menu.</p></div>
            <button onClick={openNew} className="rounded-full bg-[#c8a66a] px-5 py-3 text-xs font-semibold text-[#10110e]"><Plus className="mr-2 inline" size={15}/>Add product</button>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {[{label:"Total products",value:String(products.length),icon:Package},{label:"Available",value:String(products.filter(p=>p.status==="Available").length),icon:Check},{label:"Featured items",value:String(products.filter(p=>p.featured).length),icon:TrendingUp}].map(({label,value,icon:Icon})=><div className="panel p-5" key={label}><div className="flex justify-between"><span className="muted text-xs">{label}</span><Icon size={17} className="gold"/></div><p className="mt-4 text-3xl font-semibold">{value}</p></div>)}
          </div>
          <div className="panel mt-7 overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#252d2b] p-5"><div><h2 className="text-sm font-medium">All products</h2><p className="muted mt-1 text-[10px]">Changes here are currently held in this browser session only.</p></div><div className="relative"><Search className="muted absolute left-3 top-1/2 -translate-y-1/2" size={15}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search products..." className="w-56 rounded-full border border-[#333d38] bg-[#0c1110] py-2.5 pl-9 pr-3 text-xs outline-none focus:border-[#c8a66a]"/></div></div>
            <div className="overflow-x-auto"><table className="w-full min-w-[680px] text-left text-xs"><thead className="muted"><tr><th className="p-4 pl-5">PRODUCT</th><th className="p-4">CATEGORY</th><th className="p-4">PRICE</th><th className="p-4">STATUS</th><th className="p-4">FEATURED</th><th className="p-4"></th></tr></thead><tbody>{filtered.map(p=><tr key={p.id} className="border-t border-[#252d2b]"><td className="p-4 pl-5"><div className="flex items-center gap-3"><div className="h-10 w-10 rounded-lg bg-gradient-to-br from-[#80654a] to-[#28231d]"/><span className="font-medium">{p.name}</span></div></td><td className="p-4 muted">{p.category}</td><td className="p-4">{p.price.toFixed(2)} SAR</td><td className="p-4"><span className={`rounded-full px-3 py-1 text-[10px] ${p.status==="Available"?"bg-[#1b3027] text-[#9ed2b5]":"bg-[#392d20] text-[#e5c991]"}`}>{p.status}</span></td><td className="p-4">{p.featured?"Yes":"—"}</td><td className="p-4"><div className="flex gap-2"><button onClick={()=>openEdit(p)} aria-label="Edit product" className="rounded-lg border border-[#39413e] p-2"><Pencil size={13}/></button><button onClick={()=>removeProduct(p.id)} aria-label="Delete product" className="rounded-lg border border-[#39413e] p-2 text-[#d68b7c]"><Trash2 size={13}/></button></div></td></tr>)}</tbody></table></div>
            {filtered.length===0&&<p className="muted p-8 text-center text-sm">No products match your search.</p>}
          </div>
        </> : active === "Brand identity" ? <div className="max-w-3xl"><p className="gold text-[10px] tracking-[.2em]">YOUR BRAND</p><h1 className="mt-2 text-3xl font-semibold">Brand identity</h1><p className="muted mt-2 text-sm">Personalize the visual identity of your restaurant menu.</p><div className="panel mt-8 space-y-6 p-6"><label className="block text-xs">Restaurant display name<input value={restaurantName} onChange={e=>setRestaurantName(e.target.value)} className="mt-2 w-full rounded-xl border border-[#39413e] bg-[#0c1110] p-3 text-sm outline-none focus:border-[#c8a66a]"/></label><div><p className="text-xs">Primary brand color</p><div className="mt-3 flex items-center gap-4"><input type="color" value={brandColor} onChange={e=>setBrandColor(e.target.value)} className="h-12 w-16 cursor-pointer rounded-lg border-0 bg-transparent"/><code className="muted text-sm">{brandColor}</code><button onClick={()=>setBrandColor("#c8a66a")} className="text-xs gold">Reset default</button></div></div><div className="rounded-xl border border-[#39413e] p-5" style={{borderColor:brandColor}}><p className="text-[10px] tracking-[.2em]" style={{color:brandColor}}>LIVE PREVIEW</p><h2 className="mt-2 text-2xl">{restaurantName || "Your restaurant"}</h2><p className="muted mt-1 text-xs">Your menu identity preview</p><button className="mt-4 rounded-full px-4 py-2 text-xs text-black" style={{backgroundColor:brandColor}}>Explore menu</button></div><p className="muted text-[10px]">Prototype only: brand settings are not yet saved to the database.</p></div></div> : <div><p className="gold text-[10px] tracking-[.2em]">WORKSPACE MODULE</p><h1 className="mt-2 text-3xl font-semibold">{active}</h1><p className="muted mt-2 max-w-xl text-sm leading-6">This module is included in the product roadmap. Its production workflow will be connected to your restaurant workspace and tenant permissions in the next development pass.</p><div className="panel mt-8 max-w-2xl p-8"><div className="grid h-12 w-12 place-items-center rounded-xl bg-[#252d29]"><Settings className="gold"/></div><h2 className="mt-5 text-lg">Module foundation</h2><p className="muted mt-2 text-sm leading-6">The navigation and workspace shell are ready. We will connect this section to Supabase and add its complete management interface.</p></div></div>}
      </div>
    </section>

    {showForm && <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4"><form onSubmit={saveProduct} className="w-full max-w-lg rounded-2xl border border-[#39413e] bg-[#111615] p-6 shadow-2xl"><div className="flex items-center justify-between"><div><p className="gold text-[10px] tracking-[.2em]">MENU CATALOG</p><h2 className="mt-1 text-xl font-semibold">{editing?"Edit product":"Add product"}</h2></div><button type="button" onClick={()=>setShowForm(false)} className="rounded-lg border border-[#39413e] p-2"><X size={16}/></button></div><div className="mt-6 space-y-4"><label className="block text-xs">Product name<input required value={name} onChange={e=>setName(e.target.value)} className="mt-2 w-full rounded-xl border border-[#39413e] bg-[#0b100e] p-3 text-sm outline-none focus:border-[#c8a66a]"/></label><label className="block text-xs">Category<select value={category} onChange={e=>setCategory(e.target.value)} className="mt-2 w-full rounded-xl border border-[#39413e] bg-[#0b100e] p-3 text-sm"><option>Starters</option><option>Main courses</option><option>Desserts</option><option>Beverages</option></select></label><label className="block text-xs">Price (SAR)<input type="number" min="0" step="0.01" required value={price} onChange={e=>setPrice(e.target.value)} className="mt-2 w-full rounded-xl border border-[#39413e] bg-[#0b100e] p-3 text-sm outline-none focus:border-[#c8a66a]"/></label><label className="block text-xs">Availability<select value={status} onChange={e=>setStatus(e.target.value as "Available"|"Sold out")} className="mt-2 w-full rounded-xl border border-[#39413e] bg-[#0b100e] p-3 text-sm"><option>Available</option><option>Sold out</option></select></label></div><div className="mt-7 flex justify-end gap-3"><button type="button" onClick={()=>setShowForm(false)} className="rounded-full border border-[#39413e] px-5 py-2.5 text-xs">Cancel</button><button className="rounded-full bg-[#c8a66a] px-5 py-2.5 text-xs font-semibold text-black">{editing?"Save changes":"Create product"}</button></div></form></div>}
  </main>;
}
