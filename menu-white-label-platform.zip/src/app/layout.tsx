import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MENU — Restaurant Platform",
  description: "A white-label digital menu and restaurant management platform."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
