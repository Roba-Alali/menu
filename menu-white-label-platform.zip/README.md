# MENU White-Label Platform

A multi-tenant restaurant SaaS foundation built with Next.js, TypeScript, Supabase and Tailwind CSS.

## Current foundation
- Rebranded product identity: **MENU**.
- Premium dark marketing landing page.
- Platform owner dashboard concept at `/admin`.
- Restaurant workspace prototype at `/dashboard`.
- Public restaurant menu demo at `/demo`.
- Interactive product add/edit/delete and search in the dashboard prototype.
- Brand name and primary color live preview.
- Supabase browser/server client helpers.
- PostgreSQL schema for tenants, restaurant members, branches, categories, products, modifiers, domains, QR codes and orders.
- Initial tenant membership helpers and RLS policies.

## Run locally
Requirements: Node.js 20.9+ and npm.

```bash
npm install
cp .env.example .env.local
# Fill NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
npm run dev
```

Open `http://localhost:3000`.

## Routes
- `/` — MENU platform landing page
- `/admin` — platform owner dashboard concept (sample data)
- `/dashboard` — restaurant workspace UI prototype
- `/demo` — public menu experience prototype

## Supabase setup
1. Create a Supabase project.
2. Review and run `supabase/schema.sql` in SQL Editor.
3. Add project URL and anon key to `.env.local`.
4. Create the first owner through Supabase Auth and grant `platform_role = 'owner'` in `public.profiles`.

## Important status
The restaurant workspace currently demonstrates product CRUD and brand customization using browser-local React state. It is not yet persisted to Supabase. The admin metrics and tenant rows are illustrative sample data. Authentication, tenant provisioning, domain routing, persistent CRUD, file uploads, validated order creation, payment integrations, audit logging and production security review remain to be implemented before real customer onboarding.

Never expose `SUPABASE_SERVICE_ROLE_KEY` in browser code. Public order creation must use a server-validated endpoint or a narrowly scoped database RPC. Always calculate prices on the server and enforce tenant authorization on every read and write.

## Deployment
Deploy as a server-rendered Next.js application. For Cloudflare, use the current OpenNext Cloudflare adapter and follow its deployment documentation. Do not deploy as a static export because tenant routing and server operations are required.
