import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "QLUB Platform — Restaurant SaaS",
  description: "White-label digital menus and restaurant operations platform"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
